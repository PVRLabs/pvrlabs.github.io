package pvrlabs.coilbase;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/**
 * Immutable SQL text selection; execution and parameter contracts belong to Jdbi and callers.
 * Overrides return a new statement. Dialect keys are trimmed and case-insensitive; an unknown
 * key selects the default SQL. Selection does not detect the database or validate its syntax.
 * Enum dialect keys use their names (for example, {@code POSTGRES}); string keys match those
 * names case-insensitively or can be application-defined. {@code postgres} and {@code PostgreSQL}
 * are distinct keys; PostgreSQL is not an alias for postgres.
 * SQL text and dialect keys must be non-null and non-blank: null causes
 * {@link NullPointerException}, and blank text or keys cause {@link IllegalArgumentException}.
 * An override for an existing key replaces that key in the returned statement.
 */
public final class SqlStatement {
    private final String defaultSql;
    private final Map<String, String> overrides;

    private SqlStatement(String defaultSql, Map<String, String> overrides) {
        this.defaultSql = requireSql(defaultSql);
        this.overrides = Map.copyOf(overrides);
    }

    public static SqlStatement of(String sql) {
        return new SqlStatement(sql, Map.of());
    }

    public SqlStatement override(Dialects dialect, String sql) {
        return override(Objects.requireNonNull(dialect, "dialect").name(), sql);
    }

    public SqlStatement override(String dialect, String sql) {
        var copy = new HashMap<>(overrides);
        copy.put(dialectKey(dialect), requireSql(sql));
        return new SqlStatement(defaultSql, copy);
    }

    public SqlStatement h2(String sql) {
        return override(Dialects.H2, sql);
    }

    public SqlStatement postgres(String sql) {
        return override(Dialects.POSTGRES, sql);
    }

    /** Returns the default SQL without selecting a dialect override. */
    public String sql() {
        return defaultSql;
    }

    public String sql(Dialects dialect) {
        return sql(Objects.requireNonNull(dialect, "dialect").name());
    }

    public String sql(String dialect) {
        return overrides.getOrDefault(dialectKey(dialect), defaultSql);
    }

    static String dialectKey(String dialect) {
        String key = Objects.requireNonNull(dialect, "dialect").trim().toLowerCase(Locale.ROOT);
        if (key.isEmpty()) throw new IllegalArgumentException("dialect must not be blank");
        return key;
    }

    private static String requireSql(String sql) {
        if (Objects.requireNonNull(sql, "sql").isBlank()) {
            throw new IllegalArgumentException("SQL must not be blank");
        }
        return sql;
    }
}
